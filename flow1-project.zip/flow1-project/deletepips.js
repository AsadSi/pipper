async function deleteData(idpip) {
    const response = await fetch("http://localhost:8000", {
      method: "DELETE",
    });
    return response;
  }