window.addEventListener("load", async() => {
    let pips = await getPips();

    pips.sort((a, b) => {
      return b.idpip - a.idpip
    }).forEach((element) => {
      const pipElement = 
      fillTemplate(
        element.username, 
        element.pipmessage, 
        element.idpip, 
        element.datetime);
      document.querySelector("#pips_placeholder").appendChild(pipElement);
    });
  });

function fillTemplate(user, pipmessage, idpip, datetime){
    const template = document.querySelector("#my-template");
    const newNode = document.importNode(template.content, true);
    newNode.querySelector("img").src = `https://avatars.dicebear.com/api/bottts/${user}.svg`
    newNode.querySelector("h1").textContent = user;
    newNode.querySelector("p1").textContent = pipmessage;
    newNode.querySelector("p").textContent = idpip;
    newNode.querySelector("p2").textContent = datetime;

    var btn = newNode.getElementById("dropdownpip");
    
    btn.onclick = function() {
      document.getElementById("editModal").style.display = "block";
      console.log("Hej fra Edit Function", user, pipmessage, idpip, datetime);
    }

    var btn = newNode.getElementById("dropdownpipdelete");

    btn.onclick = async function() {
      console.log("hey")
      const deletepip = await deleteData();
    }


    return newNode;
}

async function getPips() {
  const response = await fetch("http://localhost:8000", {
    method: "GET",
  });
  return await response.json();
}


