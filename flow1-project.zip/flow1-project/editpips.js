const updatePip = document.querySelector("#editNote-form");

updatePip.addEventListener("submit", async (event) => {
  event.preventDefault();
  console.log("Hej fra update form");

  const user = document.getElementById("update_indtast_brugernavn").value
  const pip = document.getElementById("update_indtast_pip").value
  console.log(user, pip)
  const asObject = {
      username: user,
      pipmessage: pip,
  } 

  const id = document.querySelector("#modalforupdate").innerHTML;
  const response = await putData(id, asObject);
  if (response.status === 200) {
    contact.id = id;
    const newNode = createPipElement(asObject);
    const oldNode = document.querySelector("#" + id);
    oldNode.parentNode.replaceChild(newNode, oldNode);
  }
});

function clearUpdateForm() {
  const user = document.getElementById("update_indtast_brugernavn").value
  const pip = document.getElementById("update_indtast_pip").value
  console.log(user, pip)
  const asObject = {
      username: user,
      pipmessage: pip,
  } 
}

async function putData(id, fillTemplate) {
    const response = await fetch("http://localhost:8000", {
      method: "PUT",
      body: JSON.stringify(asObject),
    });
    return response;
  }